"""Base entity for Android TV Remote."""

from collections.abc import Callable
from datetime import datetime
import logging
from typing import Any, override

from androidtvremote2 import AndroidTVRemote, ConnectionClosed

from homeassistant.const import CONF_MAC, CONF_NAME
from homeassistant.core import callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import CONNECTION_NETWORK_MAC, DeviceInfo
from homeassistant.helpers.entity import Entity
from homeassistant.helpers.event import async_call_later

from .const import CONF_APPS, DOMAIN
from .helpers import AndroidTVRemoteConfigEntry, get_unavailable_grace_period

_LOGGER = logging.getLogger(__name__)


class AndroidTVRemoteBaseEntity(Entity):
    """Android TV Remote Base Entity."""

    _attr_name = None
    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(
        self, api: AndroidTVRemote, config_entry: AndroidTVRemoteConfigEntry
    ) -> None:
        """Initialize the entity."""
        self._api = api
        self._apps: dict[str, Any] = config_entry.options.get(CONF_APPS, {})
        self._attr_unique_id = config_entry.unique_id
        self._attr_is_on = api.is_on
        self._grace_period = get_unavailable_grace_period(config_entry)
        self._cancel_unavailable: Callable[[], None] | None = None
        device_info = api.device_info
        assert config_entry.unique_id
        assert device_info
        self._attr_device_info = DeviceInfo(
            connections={(CONNECTION_NETWORK_MAC, config_entry.data[CONF_MAC])},
            identifiers={(DOMAIN, config_entry.unique_id)},
            name=config_entry.data[CONF_NAME],
            manufacturer=device_info["manufacturer"],
            model=device_info["model"],
        )

    @callback
    def _is_available_updated(self, is_available: bool) -> None:
        """Update the state when the device is ready or unavailable.

        A lost connection is only reported after the grace period, so that a
        quick reconnect does not make the entity flap to unavailable.
        """
        if is_available:
            self._cancel_pending_unavailable()
            if not self._attr_available:
                self._attr_available = True
                self.async_write_ha_state()
            return
        if self._grace_period <= 0:
            self._set_unavailable()
            return
        if self._cancel_unavailable is None and self._attr_available:
            _LOGGER.debug(
                "%s: connection lost, marking unavailable in %s seconds"
                " unless it reconnects",
                self.entity_id,
                self._grace_period,
            )
            self._cancel_unavailable = async_call_later(
                self.hass, self._grace_period, self._grace_period_expired
            )

    @callback
    def _grace_period_expired(self, _now: datetime) -> None:
        """Mark the entity unavailable once the grace period is over."""
        self._cancel_unavailable = None
        self._set_unavailable()

    @callback
    def _set_unavailable(self) -> None:
        self._cancel_pending_unavailable()
        if self._attr_available:
            self._attr_available = False
            self.async_write_ha_state()

    @callback
    def _cancel_pending_unavailable(self) -> None:
        if self._cancel_unavailable is not None:
            self._cancel_unavailable()
            self._cancel_unavailable = None

    @callback
    def _is_on_updated(self, is_on: bool) -> None:
        """Update the state when device turns on or off."""
        self._attr_is_on = is_on
        self.async_write_ha_state()

    @override
    async def async_added_to_hass(self) -> None:
        """Register callbacks."""
        self._api.add_is_available_updated_callback(self._is_available_updated)
        self._api.add_is_on_updated_callback(self._is_on_updated)

    @override
    async def async_will_remove_from_hass(self) -> None:
        """Remove callbacks."""
        self._api.remove_is_available_updated_callback(self._is_available_updated)
        self._api.remove_is_on_updated_callback(self._is_on_updated)
        self._cancel_pending_unavailable()

    def _send_key_command(self, key_code: str, direction: str = "SHORT") -> None:
        """Send a key press to Android TV.

        This does not block; it buffers the data and arranges
        for it to be sent out asynchronously.
        """
        try:
            self._api.send_key_command(key_code, direction)
        except ConnectionClosed as exc:
            raise HomeAssistantError(
                translation_domain=DOMAIN, translation_key="connection_closed"
            ) from exc

    def _send_launch_app_command(self, app_link: str) -> None:
        """Launch an app on Android TV.

        This does not block; it buffers the data and arranges
        for it to be sent out asynchronously.
        """
        try:
            self._api.send_launch_app_command(app_link)
        except ConnectionClosed as exc:
            raise HomeAssistantError(
                translation_domain=DOMAIN, translation_key="connection_closed"
            ) from exc
