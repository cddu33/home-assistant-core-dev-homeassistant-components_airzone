"""Helper functions for Android TV Remote integration."""

from androidtvremote2 import AndroidTVRemote

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import STORAGE_DIR

from .const import (
    CONF_ENABLE_IME,
    CONF_ENABLE_IME_DEFAULT_VALUE,
    CONF_IDLE_TIMEOUT,
    CONF_IDLE_TIMEOUT_DEFAULT_VALUE,
    CONF_UNAVAILABLE_GRACE_PERIOD,
    CONF_UNAVAILABLE_GRACE_PERIOD_DEFAULT_VALUE,
)

AndroidTVRemoteConfigEntry = ConfigEntry[AndroidTVRemote]


def create_api(hass: HomeAssistant, host: str, enable_ime: bool) -> AndroidTVRemote:
    """Create an AndroidTVRemote instance."""
    return AndroidTVRemote(
        client_name="Home Assistant",
        certfile=hass.config.path(STORAGE_DIR, "androidtv_remote_cert.pem"),
        keyfile=hass.config.path(STORAGE_DIR, "androidtv_remote_key.pem"),
        host=host,
        loop=hass.loop,
        enable_ime=enable_ime,
    )


def get_enable_ime(entry: AndroidTVRemoteConfigEntry) -> bool:
    """Get value of enable_ime option or its default value."""
    return bool(entry.options.get(CONF_ENABLE_IME, CONF_ENABLE_IME_DEFAULT_VALUE))


def get_unavailable_grace_period(entry: AndroidTVRemoteConfigEntry) -> int:
    """Get value of unavailable_grace_period option or its default value."""
    return int(
        entry.options.get(
            CONF_UNAVAILABLE_GRACE_PERIOD, CONF_UNAVAILABLE_GRACE_PERIOD_DEFAULT_VALUE
        )
    )


def get_idle_timeout(entry: AndroidTVRemoteConfigEntry) -> int:
    """Get value of idle_timeout option or its default value."""
    return int(entry.options.get(CONF_IDLE_TIMEOUT, CONF_IDLE_TIMEOUT_DEFAULT_VALUE))
